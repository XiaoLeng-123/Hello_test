package com.ljc.spring.dao;

import org.springframework.stereotype.Repository;

@Repository
public class PersonDao {

}
