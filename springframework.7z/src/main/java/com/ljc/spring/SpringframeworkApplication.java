package com.ljc.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringframeworkApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringframeworkApplication.class, args);
	}

}
