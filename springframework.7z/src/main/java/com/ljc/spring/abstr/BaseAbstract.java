package com.ljc.spring.abstr;

public abstract class BaseAbstract<T> {
	
	public abstract void save();

}
