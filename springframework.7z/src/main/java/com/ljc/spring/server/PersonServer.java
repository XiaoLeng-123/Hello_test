package com.ljc.spring.server;

public interface PersonServer {

	String gerPerson();
}
