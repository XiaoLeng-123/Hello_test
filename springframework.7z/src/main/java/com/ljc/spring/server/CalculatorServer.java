package com.ljc.spring.server;


import org.springframework.stereotype.Service;

@Service
public interface CalculatorServer {
	
	public int add(int a,int b);

}
