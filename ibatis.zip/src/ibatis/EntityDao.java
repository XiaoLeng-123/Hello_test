package ibatis;

public interface EntityDao {

	
	
	public default EntityPojo selectBlog(int id) {
		
		return null;
		
	}
}
