package ibatis.text;

import static org.junit.Assert.*;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import ibatis.EntityDao;
import ibatis.EntityPojo;

public class Weeeee {

	@Test
	public void www() {
		String resource = "mybatis-config.xml";
		InputStream inputStream;
		try {
			inputStream = Resources.getResourceAsStream(resource);
			SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
			
			try (SqlSession session = sqlSessionFactory.openSession()) {
				EntityDao mapper = session.getMapper(EntityDao.class);
				EntityPojo blog = mapper.selectBlog(101);
				System.out.println(blog);
				}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
