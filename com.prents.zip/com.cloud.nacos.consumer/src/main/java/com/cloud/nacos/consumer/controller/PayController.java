package com.cloud.nacos.consumer.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class PayController {

}
