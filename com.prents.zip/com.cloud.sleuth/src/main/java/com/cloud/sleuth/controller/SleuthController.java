package com.cloud.sleuth.controller;

import org.springframework.web.bind.annotation.RestController;



@RestController
public class SleuthController {

}
