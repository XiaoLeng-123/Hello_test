package com.config.rabbitmqsource.service;

public interface IMessageProviderService {

	public String send();
}
